package clases;

import formularios.frmLogin;

/**
 *
 * @author leandraroque
 */
public class LeaAplication {

    public static void main(String[] args) {
        // TODO code application logic here
        
        frmLogin miLogin = new frmLogin();
        miLogin.setLocationRelativeTo(null);
        miLogin.setVisible (true);
    }
    
}
